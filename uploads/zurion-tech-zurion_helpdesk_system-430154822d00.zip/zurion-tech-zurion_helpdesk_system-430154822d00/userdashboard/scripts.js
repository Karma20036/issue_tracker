document.addEventListener('DOMContentLoaded', () => {
    showSection('raise-ticket');
});

function showSection(sectionId) {
    const sections = document.querySelectorAll('.content-section');
    sections.forEach(section => {
        section.classList.remove('active');
    });

    const activeSection = document.getElementById(sectionId);
    if (activeSection) {
        activeSection.classList.add('active');
    }

    if (sectionId === 'view-tickets') {
        fetch('view_tickets.php')
            .then(response => response.text())
            .then(data => {
                activeSection.innerHTML = `<h2>View My Tickets</h2>${data}`;
            });
    }
}

function fetchTicketDetails(sectionId, ticketId) {
    fetch(`fetch_ticket_details.php?id=${ticketId}`)
        .then(response => response.json())
        .then(data => {
            if (data) {
                document.querySelector(`#${sectionId} #category`).value = data.category;
                document.querySelector(`#${sectionId} #description`).value = data.description;
                document.querySelector(`#${sectionId} #attachments`).innerHTML = data.attachments;
            }
        });
}
