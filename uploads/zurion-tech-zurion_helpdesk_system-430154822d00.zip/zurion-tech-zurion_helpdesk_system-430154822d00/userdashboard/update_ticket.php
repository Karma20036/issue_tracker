<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $category = $_POST['category'];
    $description = $_POST['description'];
    $attachments = '';

    if (!empty($_FILES['attachments']['name'][0])) {
        $targetDir = "uploads/";
        foreach ($_FILES['attachments']['name'] as $key => $name) {
            $targetFile = $targetDir . basename($name);
            if (move_uploaded_file($_FILES['attachments']['tmp_name'][$key], $targetFile)) {
                $attachments .= $targetFile . ';';
            }
        }
    }

    $sql = "UPDATE tickets SET category='$category', description='$description', attachments='$attachments' WHERE id=$id";
    
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Ticket updated successfully'); window.location.href='index.html';</script>";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}
?>
