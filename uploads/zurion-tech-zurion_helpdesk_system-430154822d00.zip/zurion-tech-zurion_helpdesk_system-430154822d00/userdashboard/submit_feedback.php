<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ticket_id = $_POST['ticket_id'];
    $resolved = $_POST['resolved'];
    $service_rating = $_POST['service_rating'];
    $comments = $_POST['comments'];

    $sql = "INSERT INTO feedback (ticket_id, resolved, service_rating, comments) VALUES ('$ticket_id', '$resolved', '$service_rating', '$comments')";
    
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Feedback submitted successfully'); window.location.href='index.html';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>
