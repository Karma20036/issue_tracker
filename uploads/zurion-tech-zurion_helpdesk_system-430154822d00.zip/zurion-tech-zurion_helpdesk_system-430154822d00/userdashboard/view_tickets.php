<?php
include 'config.php';

$pendingTickets = $conn->query("SELECT * FROM tickets WHERE status='Open'");
$recentTickets = $conn->query("SELECT * FROM tickets ORDER BY updated_at DESC LIMIT 10");
$cancelledTickets = $conn->query("SELECT * FROM tickets WHERE status='Cancelled'");
$ticketHistory = $conn->query("SELECT * FROM tickets");

function displayTable($result, $title) {
    echo "<h3>$title</h3>";
    echo "<table border='1'>";
    echo "<tr><th>ID</th><th>Category</th><th>Description</th><th>Attachments</th><th>Status</th><th>Reason</th><th>Created At</th><th>Updated At</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["id"] . "</td>";
        echo "<td>" . $row["category"] . "</td>";
        echo "<td>" . $row["description"] . "</td>";
        echo "<td>" . $row["attachments"] . "</td>";
        echo "<td>" . $row["status"] . "</td>";
        echo "<td>" . $row["reason"] . "</td>";
        echo "<td>" . $row["created_at"] . "</td>";
        echo "<td>" . $row["updated_at"] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}

displayTable($pendingTickets, 'Pending Tickets');
displayTable($recentTickets, 'Recent Tickets');
displayTable($cancelledTickets, 'Cancelled Tickets');
displayTable($ticketHistory, 'Ticket History');

$conn->close();
?>
