<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $reason = $_POST['reason'];

    $sql = "UPDATE tickets SET status='Cancelled', reason='$reason' WHERE id=$id";
    
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Ticket cancelled successfully'); window.location.href='index.html';</script>";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}
?>
