<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $category = $_POST['category'];
    $description = $_POST['description'];
    $attachments = '';

    if (!empty($_FILES['attachments']['name'][0])) {
        $targetDir = "uploads/";
        foreach ($_FILES['attachments']['name'] as $key => $name) {
            $targetFile = $targetDir . basename($name);
            if (move_uploaded_file($_FILES['attachments']['tmp_name'][$key], $targetFile)) {
                $attachments .= $targetFile . ';';
            }
        }
    }

    $sql = "INSERT INTO tickets (category, description, attachments) VALUES ('$category', '$description', '$attachments')";
    
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('New ticket created successfully'); window.location.href='index.html';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>
